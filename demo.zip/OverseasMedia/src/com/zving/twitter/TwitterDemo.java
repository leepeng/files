/*
 * Copyright (c) 2007, 2018, Zving and/or its affiliates. All rights reserved.
 * Zving PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
package com.zving.twitter;

import java.io.File;

import com.zving.facebook.util.StringUtil;

import twitter4j.Status;
import twitter4j.StatusUpdate;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.UploadedMedia;
import twitter4j.conf.Configuration;
import twitter4j.conf.ConfigurationBuilder;

/**
 * 使用Twitter4j向Twitter平台推送消息Demo
 * 
 * @author Alex.Lee
 * @date 28th Feb,2018
 * @mail lp@zing.com
 */
public class TwitterDemo {
	private static UploadedMedia videoMedia = null;
	private static final Object LOCK = new Object();
	private static Status updateStatus = null;
	public static void main(String[] args) throws TwitterException, InterruptedException {
		
		Configuration twitterConfiguration = TwitterUtil.getTwitterConfiguration();
		Twitter twitter =  new TwitterFactory(twitterConfiguration).getInstance();
		StatusUpdate updateContent = new StatusUpdate("this is a test message!");
		twitter.updateStatus(updateContent);
		
		
		
		// 文本消息，注意：根据Twitter官方文档，汉字长度不超过140字符，英文长度不超过280字符
		String text = "Hello,this is a test message!";

		// demo1: =========发布文本消息=======
		// System.out.println(publishText(twitter, text));

		// 发布图片。注意：Twitter最大可以发布4张图片,且动图GIF不能和静态图片放在一起发，gif图片一次只能发一张。
		String pic1 = "C:\\Users\\Mr.Lee\\Pictures\\Saved Pictures\\562dcd229cba9.jpg";
		String pic2 = "C:\\Users\\Mr.Lee\\Pictures\\Saved Pictures\\7730-150331161413-51.jpg";
		String pic3 = "C:\\Users\\Mr.Lee\\Pictures\\Saved Pictures\\152356mgfk3ev317p12119.jpg";
		String pic4 = "C:\\Users\\Mr.Lee\\Pictures\\Saved Pictures\\174911drrgrgsoq3anral0.jpg";
		String pic[] = { pic1, pic2, pic3, pic4 };
		text = "测试上传图片！";

		// demo2: =========发布图片消息======
		// System.out.println(publishImages(twitter,text,pic));

		// demo3: =========发布视频=======
		//String videoUrl = "D:\\28.mp4";

	}
//		AsyncTwitter asyncTwitter = new AsyncTwitterFactory(conf).getInstance();
//		asyncTwitter.addListener(new TwitterAdapter() {
//			@Override
//			public void uploadVideo(UploadedMedia uploadMedia) {
//				videoMedia = uploadMedia;
//				// System.out.println(uploadMedia.toString());
//				System.out.println("上传视频成功，视频media_id为" + uploadMedia.getMediaId());
//				synchronized (LOCK) {
//					LOCK.notify();
//				}
//			}
//
//			@Override
//			public void updatedStatus(Status status) {
//				updateStatus = status;
//				// System.out.println(status.toString());
//				System.out.println("发布twitter视频消息成功，twitter消息id为" + status.getId());
//				synchronized (LOCK) {
//					LOCK.notify();
//				}
//			}
//
//			@Override
//			public void onException(TwitterException e, TwitterMethod method) {
//				if (method == UPDATE_STATUS) {
//					e.printStackTrace();
//					synchronized (LOCK) {
//						LOCK.notify();
//					}
//				} else {
//					synchronized (LOCK) {
//						LOCK.notify();
//					}
//					throw new AssertionError("发布twitter视频消息发生异常Should not happen");
//				}
//			}
//
//		});
//		// 保存上传视频之后得到media_id的数组,每次只能上传一个视频
//		long[] mediaIds = new long[1];
//		asyncTwitter.uploadVideo(new File(videoUrl));
//		synchronized (LOCK) {
//			LOCK.wait();
//		}
//		mediaIds[0] = videoMedia.getMediaId();
//		// 生成发送内容，并添加发送的文字
//		StatusUpdate updateContent = new StatusUpdate(text);
//		// 向发布内容里添加视频文件media_id
//		updateContent.setMediaIds(mediaIds);
//		// 异步发送twitter整条消息
//		asyncTwitter.updateStatus(updateContent);
//		synchronized (LOCK) {
//			LOCK.wait();
//		}
//		System.out.println(updateStatus);
//
//	}


	/**
	 * 上传图片
	 * 
	 * @param twitter
	 * @param message
	 * @param pic
	 * @return
	 * @throws TwitterException
	 */
	private static Status publishImages(Twitter twitter, String message, String[] pic) throws TwitterException {
		int imgLimit = pic.length < 4 ? pic.length : 4;
		long[] mediaIds = new long[imgLimit];
		for (int i = 0; i < pic.length; i++) {
			UploadedMedia media = twitter.uploadMedia(new File(pic[i]));
			mediaIds[i] = media.getMediaId();
		}
		StatusUpdate updateContent = new StatusUpdate(message);
		updateContent.setMediaIds(mediaIds);
		Status updateStatus = twitter.updateStatus(updateContent);
		try {
			// 睡500ms，等待上传时间
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return updateStatus;

	}

	private static Status publishText(Twitter twitter, String text) throws TwitterException {
		// 发布文字
		StatusUpdate updateContent = new StatusUpdate(text);
		return twitter.updateStatus(updateContent);
	}
	
	/**
	 * 删除twitter帖子
	 * @param consumerKey
	 * @param consumerSecret
	 * @param token
	 * @param tokenSecret
	 * @param twitterId
	 * @return
	 */
	@SuppressWarnings("finally")
	public boolean delete(String consumerKey, String consumerSecret, String token, String tokenSecret, String proxyHost,
			Integer proxyPort, String twitterId) {
		boolean flag = false;
		try {
			ConfigurationBuilder confBuilder = new ConfigurationBuilder();
			confBuilder.setOAuthConsumerKey(consumerKey);
			confBuilder.setOAuthConsumerSecret(consumerSecret);
			confBuilder.setOAuthAccessToken(token);
			confBuilder.setOAuthAccessTokenSecret(tokenSecret);
			if (StringUtil.isNotEmpty(proxyHost) && proxyPort != null && proxyPort > 0) {
				confBuilder.setHttpProxyHost(proxyHost);
				confBuilder.setHttpProxyPort(proxyPort);
			}
			Configuration conf = confBuilder.build();
			Twitter twitter = new TwitterFactory(conf).getInstance();
			twitter.destroyStatus(new Long(twitterId));
			flag = true;
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (TwitterException e) {
			e.printStackTrace();
		} finally {
			return flag;
		}
	}
}
