package com.zving.twitter;

import twitter4j.conf.Configuration;
import twitter4j.conf.ConfigurationBuilder;

public class TwitterUtil {
	public static Configuration getTwitterConfiguration() {
		ConfigurationBuilder confBuilder = new ConfigurationBuilder();
		// 设置AppKey,根据实际情况设置
		confBuilder.setOAuthConsumerKey("WaTJWBrBvpcmuhhHeDA3Pgrme");
		// 设置Secret 根据实际情况设置
		confBuilder.setOAuthConsumerSecret("h7MhfteeiRqCZ1qTTnVwyAxdZMkcpukhn6qCiOl9yVAOR1aCTy");
		// 设置token 根据实际情况设置
		confBuilder.setOAuthAccessToken("737311988854849537-TYd1iZsWc0Tq9QPcULxBCPpPLtbKFVS");
		// 设置TokenSecret 根据实际情况设置
		confBuilder.setOAuthAccessTokenSecret("WT5FtAN1Ajho8yZgYRmZrou0Xi8D14gByMk5IKS2bBwaX");
		// 设置代理服务器，如果使用VPN，则需要设置代理服务器，如果是专线可以不用代理
		confBuilder.setHttpProxyHost("127.0.0.1");
		confBuilder.setHttpProxyPort(2125);
		return confBuilder.build();
	}
}
