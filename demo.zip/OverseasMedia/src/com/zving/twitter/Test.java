package com.zving.twitter;

import static twitter4j.TwitterMethod.UPDATE_STATUS;

import java.io.File;

import twitter4j.AsyncTwitter;
import twitter4j.AsyncTwitterFactory;
import twitter4j.Status;
import twitter4j.StatusUpdate;
import twitter4j.TwitterAdapter;
import twitter4j.TwitterException;
import twitter4j.TwitterMethod;
import twitter4j.UploadedMedia;

public class Test {
	private static UploadedMedia videoMedia = null;
	private static final Object LOCK = new Object();
	private static Status updateStatus = null;
	public static void main(String[] args) throws TwitterException, InterruptedException {
		// 有要发布的视频时，异步上传视频
		AsyncTwitter asyncTwitter = new AsyncTwitterFactory(TwitterUtil.getTwitterConfiguration()).getInstance();
		asyncTwitter.addListener(new TwitterAdapter() {
			@Override
			public void uploadVideo(UploadedMedia uploadMedia) {
				videoMedia = uploadMedia;
				// System.out.println(uploadMedia.toString());
				System.out.println("上传视频成功，视频media_id为" + uploadMedia.getMediaId());
				synchronized (LOCK) {
					LOCK.notify();
				}
			}

			@Override
			public void updatedStatus(Status status) {
				updateStatus = status;
				// System.out.println(status.toString());
				System.out.println("发布twitter视频消息成功，twitter消息id为" + status.getId());
				synchronized (LOCK) {
					LOCK.notify();
				}
			}

			@Override
			public void onException(TwitterException e, TwitterMethod method) {
				if (method == UPDATE_STATUS) {
					e.printStackTrace();
					synchronized (LOCK) {
						LOCK.notify();
					}
				} else {
					synchronized (LOCK) {
						LOCK.notify();
					}
					throw new AssertionError("发布twitter视频消息发生异常Should not happen");
				}
			}

		});
		// 保存上传视频之后得到media_id的数组,每次只能上传一个视频
		long[] mediaIds = new long[1];
		asyncTwitter.uploadVideo(new File("D:\\28.mp4"));
		synchronized (LOCK) {
			LOCK.wait();
		}
		mediaIds[0] = videoMedia.getMediaId();
		// 生成发送内容，并添加发送的文字
		StatusUpdate updateContent = new StatusUpdate("这是测试视频！");
		// 向发布内容里添加视频文件media_id
		updateContent.setMediaIds(mediaIds);
		// 异步发送twitter整条消息
		asyncTwitter.updateStatus(updateContent);
		synchronized (LOCK) {
			LOCK.wait();
		}
		System.out.println(updateStatus);

	}
}
