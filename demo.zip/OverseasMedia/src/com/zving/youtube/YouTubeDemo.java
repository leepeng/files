package com.zving.youtube;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import com.google.api.client.auth.oauth2.BearerToken;
import com.google.api.client.auth.oauth2.ClientParametersAuthentication;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.googleapis.auth.oauth2.GoogleRefreshTokenRequest;
import com.google.api.client.googleapis.media.MediaHttpUploader;
import com.google.api.client.googleapis.media.MediaHttpUploaderProgressListener;
import com.google.api.client.http.InputStreamContent;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.youtube.YouTube;
import com.google.api.services.youtube.model.Video;
import com.google.api.services.youtube.model.VideoSnippet;
import com.google.api.services.youtube.model.VideoStatus;
import com.zving.facebook.util.StringUtil;
import com.zving.util.GoogleAuth;
import com.zving.util.HttpsCertUtil;

public class YouTubeDemo {
	private JsonFactory jacksonFactory = new JacksonFactory();
	private static final String VIDEO_FILE_FORMAT = "video/*";
	/**
	 * 如果有代理信息，设置代理同时忽略https证书的信任问题
	 * 
	 * @param proxyHost
	 * @param proxyPort
	 * @return
	 * @throws Exception
	 */
	private NetHttpTransport getHttpTransport(String proxyHost, Integer proxyPort) throws Exception {
		NetHttpTransport httpTransport = (NetHttpTransport) new NetHttpTransport();		
		if (StringUtil.isNotEmpty(proxyHost) && proxyPort != null && proxyPort > 0) {
			InetSocketAddress proxyLocation = new InetSocketAddress(proxyHost, proxyPort);
			Proxy proxy = new Proxy(Proxy.Type.HTTP, proxyLocation);

			httpTransport = new NetHttpTransport.Builder().setProxy(proxy)
					.setHostnameVerifier(HttpsCertUtil.ignoreVerifier)
					.setSslSocketFactory(HttpsCertUtil.getIgnoreSSLSocketFactory()).build();
		}
		return httpTransport;
	}
	
	public Object send(String accessToken, String refreshToken, String client_id, String client_secret,
			String proxyHost, Integer proxyPort,String title,String description,List<String> videoList) throws Exception {
		Video sendResult = null;
		try{	
			// Demo
			// http://www.oschina.net/code/piece_full?code=53575&piece=78851
			NetHttpTransport transHttp = getHttpTransport(proxyHost, proxyPort);

			Credential cred = new Credential.Builder(BearerToken.authorizationHeaderAccessMethod())
				.setJsonFactory(GoogleAuth.JSON_FACTORY).setTransport(transHttp)
				.setTokenServerEncodedUrl("https://accounts.google.com/o/oauth2/token")
				.setClientAuthentication(new ClientParametersAuthentication(client_id, client_secret)).build();
			cred.setAccessToken(accessToken);
			cred.setExpiresInSeconds(0l);
			cred.setRefreshToken(refreshToken);		

			if (cred.getExpiresInSeconds() < 180) {
				GoogleRefreshTokenRequest refreshRequest = new GoogleRefreshTokenRequest(transHttp,
						jacksonFactory, cred.getRefreshToken(), client_id, client_secret);
				TokenResponse tokenResponse;
				tokenResponse = refreshRequest.execute();
				tokenResponse.setRefreshToken(cred.getRefreshToken());
				cred.setAccessToken(tokenResponse.getAccessToken());
				cred.setExpiresInSeconds(tokenResponse.getExpiresInSeconds());

				YouTube youtube = new YouTube.Builder(transHttp, jacksonFactory, cred)
						.setApplicationName("new-china").build();

				// 取得发布视频的List
				//List videoList = item.getVideoList();

				if (videoList != null && videoList.size() > 0) {
					// 取得视频文件名及路径
					String fileName = (String) videoList.get(0);
					File videoFile = new File(fileName);
					FileInputStream fileStream = new FileInputStream(fileName);

					Video videoObjectDefiningMetadata = new Video();

					VideoStatus status = new VideoStatus();
					status.setPrivacyStatus("public");
					videoObjectDefiningMetadata.setStatus(status);
					VideoSnippet snippet = new VideoSnippet();
					snippet.setTitle(title);
					snippet.setDescription(description);
					videoObjectDefiningMetadata.setSnippet(snippet);

					InputStreamContent mediaContent = new InputStreamContent(VIDEO_FILE_FORMAT, fileStream);
					mediaContent.setLength(fileStream.getChannel().size());
					YouTube.Videos.Insert videoInsert = youtube.videos().insert("snippet,statistics,status",
							videoObjectDefiningMetadata, mediaContent);

					MediaHttpUploader uploader = videoInsert.getMediaHttpUploader();
					uploader.setDirectUploadEnabled(false);

					MediaHttpUploaderProgressListener progressListener = new MediaHttpUploaderProgressListener() {
						public void progressChanged(MediaHttpUploader uploader) throws IOException {
							switch (uploader.getUploadState()) {
							case INITIATION_STARTED:
								System.out.println("Initiation Started");
								break;
							case INITIATION_COMPLETE:
								System.out.println("Initiation Completed");
								break;
							case MEDIA_IN_PROGRESS:
								System.out.println("Upload percentage: "
										+ String.format("%3.0f", uploader.getProgress() * 100) + "%");
								break;
							case MEDIA_COMPLETE:
								System.out.println("Upload Completed!");
								break;
							case NOT_STARTED:
								System.out.println("Upload Not Started!");
								break;
							}

						}
					};

					uploader.setProgressListener(progressListener);
					long start = System.currentTimeMillis();
					sendResult = videoInsert.execute();
					long currentTime = System.currentTimeMillis();
					long usetime = (currentTime - start) / 1000;

					// Print data about the newly inserted video from the API
					// response.
					System.out.println("\n================== Returned Video ==================\n");
					System.out.println("  - id: " + sendResult.getId());
					System.out.println("  - 标题: " + sendResult.getSnippet().getTitle());
					System.out.println("  - 标签: " + sendResult.getSnippet().getTags());
					System.out.println("  - Privacy Status: " + sendResult.getStatus().getPrivacyStatus());
					System.out.println("  - Video Count: " + sendResult.getStatistics().getViewCount());
					System.out.println("  - Monetization Detail: " + sendResult.getMonetizationDetails());
					System.out.println(MessageFormat.format("视频{0}上传成功！文件大小  {1} KB,用时 {2} s ,上传速度 {3} KB/s", videoFile.getName(),
									videoFile.length() / 1024, usetime, videoFile.length() / 1024 / usetime));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return sendResult;
	}
	
	/**
	 * 删除Youtube上的帖子
	 * @param accessToken
	 * @param refreshToken
	 * @param client_id
	 * @param client_secret
	 * @param videoId
	 * @return
	 * @throws Exception 
	 */
	@SuppressWarnings("finally")
	public boolean delete(String accessToken, String refreshToken, String client_id, String client_secret,
			String proxyHost, Integer proxyPort, String videoId) throws Exception {
		NetHttpTransport transHttp = getHttpTransport(proxyHost, proxyPort);
		boolean flag = false;
		try {
			Credential cred = new Credential.Builder(BearerToken.authorizationHeaderAccessMethod())
					.setJsonFactory(GoogleAuth.JSON_FACTORY)
					.setTransport(transHttp)
					.setTokenServerEncodedUrl("https://accounts.google.com/o/oauth2/token")
					.setClientAuthentication(new ClientParametersAuthentication(client_id, client_secret))
					.build();
			cred.setAccessToken(accessToken);
			cred.setExpiresInSeconds(0l);
			cred.setRefreshToken(refreshToken);
			
			if (cred.getExpiresInSeconds()<180){
				GoogleRefreshTokenRequest refreshRequest = new GoogleRefreshTokenRequest(transHttp,
						jacksonFactory, cred.getRefreshToken(), client_id, client_secret);
			    TokenResponse tokenResponse;

			    tokenResponse = refreshRequest.execute();
			    tokenResponse.setRefreshToken(cred.getRefreshToken());
			    cred.setAccessToken(tokenResponse.getAccessToken());
			    cred.setExpiresInSeconds(tokenResponse.getExpiresInSeconds());
			
				YouTube youtube = new YouTube.Builder(transHttp, jacksonFactory, cred)
						.setApplicationName("new-china").build();
			    
			    youtube.videos().delete(videoId).execute();
			    flag = true;
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			return flag;
		}
			  
	}
	
	public static void main(String[] args) throws Exception {
		String accessToken = "ya29.GlsVBeWwQUHXPKh1dAdnFmoJ_V52Jw7DX62xSFFaXqa7pvLkrk35EdKbQ6DBA47VwlTImDesxnD5XyCZv0t0BPzAq0Y_EXVcTVo79I_TdXCS4gdijTKzt32JaSmk";
		String refreshToken = "1/RL_mgbfU4AXJgAl3dc8XD8kN-uKNuRlvraLKaHzVbds";
		String client_id = "473295344077-lqlpjpouapqb6ed1nfdpgnkiltrpt346.apps.googleusercontent.com";
		String client_secret = "nHo9z95tDAMmvtqOgBb6QopJ";
		String proxyHost = "127.0.0.1";
		int proxyPort = 2125;
		String title = "测试视频";
		String description = "测试视频描述";
		List<String>videoList = new ArrayList<String>();
		videoList.add("D:\\28.mp4");
		System.out.println(new YouTubeDemo().send(accessToken, refreshToken, client_id, client_secret, proxyHost, proxyPort, title, description, videoList));
	}
}
