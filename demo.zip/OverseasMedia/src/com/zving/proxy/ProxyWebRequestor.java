package com.zving.proxy;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import com.restfb.DefaultWebRequestor;
/**
 * 
 * @author Alex.Lee
 *
 */
public class ProxyWebRequestor extends DefaultWebRequestor{
	public static final String HTTP = "http";
	public static final String HTTPS = "https";
	
	private String proxyHost;
	private Integer proxyPort;
	/**
	 * 不验证主机
	 */
	final static HostnameVerifier DO_NOT_VERIFY = new HostnameVerifier() {
		public boolean verify(String hostname, SSLSession session) {
			return true;
		}
	};
	
	
	public ProxyWebRequestor(String proxyHost,Integer proxyPort) {
		this.proxyHost = proxyHost;
		this.proxyPort = proxyPort;
	}


	@Override
	protected HttpURLConnection openConnection(URL url) throws IOException {
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort)); 
		if(HTTP.equals(url.getProtocol())){
			return (HttpURLConnection) url.openConnection(proxy);
		}else if(HTTPS.equals(url.getProtocol())){
			HttpsURLConnection httpsURLConnection = (HttpsURLConnection)url.openConnection(proxy);
			httpsURLConnection.setHostnameVerifier(DO_NOT_VERIFY);
			return httpsURLConnection;
		}
		return null;
	}
	
}
