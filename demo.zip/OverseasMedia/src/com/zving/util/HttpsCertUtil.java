package com.zving.util;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;

/**
 * 忽略ssl证书问题
 * @author wanghy
 * @date 2017年3月8日
 */
public class HttpsCertUtil {
	
	/**
	 * 参考http://mengyang.iteye.com/blog/575671
	 * @throws Exception
	 */
	public static void ignore() throws Exception{
		trustAllHttpsCertificates();  
		HttpsURLConnection.setDefaultHostnameVerifier(ignoreVerifier);  
	}
	
	public static void restore() throws Exception{
		//TODO 
	}
	
	public static HostnameVerifier ignoreVerifier = new HostnameVerifier() {
		public boolean verify(String urlHostName, SSLSession session) {
			System.out.println("Warning: URL Host: " + urlHostName + " vs. " + session.getPeerHost());
			return true;
		}
	};
	
	public static SSLSocketFactory getIgnoreSSLSocketFactory() throws Exception{
		SSLContext sslContext = getIgnoreSSLContext();
		return sslContext.getSocketFactory();
	}

	private static void trustAllHttpsCertificates() throws Exception {
		SSLContext sslContext = getIgnoreSSLContext();
		HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
	}
	
	private static SSLContext getIgnoreSSLContext() throws NoSuchAlgorithmException, KeyManagementException{
		javax.net.ssl.TrustManager[] trustAllCerts = new javax.net.ssl.TrustManager[1];
		javax.net.ssl.TrustManager tm = new miTM();
		trustAllCerts[0] = tm;
		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, null);
		return sc;		
	}

	static class miTM implements javax.net.ssl.TrustManager, javax.net.ssl.X509TrustManager {
		public java.security.cert.X509Certificate[] getAcceptedIssuers() {
			return null;
		}

		public boolean isServerTrusted(java.security.cert.X509Certificate[] certs) {
			return true;
		}

		public boolean isClientTrusted(java.security.cert.X509Certificate[] certs) {
			return true;
		}

		public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType)
				throws java.security.cert.CertificateException {
			return;
		}

		public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType)
				throws java.security.cert.CertificateException {
			return;
		}
	}

}
