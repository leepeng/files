package com.zving.facebook;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.text.MessageFormat;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.GetMethod;

import com.alibaba.fastjson.JSONArray;
import com.restfb.BinaryAttachment;
import com.restfb.DefaultFacebookClient;
import com.restfb.DefaultJsonMapper;
import com.restfb.FacebookClient;
import com.restfb.Parameter;
import com.restfb.Version;
import com.restfb.types.Album;
import com.restfb.types.FacebookType;
import com.zving.facebook.util.StringUtil;
import com.zving.proxy.ProxyWebRequestor;

public class FacebookDemo {
	public static FacebookClient facebookClient = null;
	private static String albumUrl = "https://graph.facebook.com/{0}/{1}?fields=photos{2}&access_token={3}";
	static String accessToken = "EAAUEuE34TvYBAKiEgskoJRqStxjgEHJ26r4V4DwNhvnaxPFsRLuAwJ5ZCF6jLnkPw57TFSEZCIfjNF0tDT4PwFG3gzg9htRRQUPl59wrwIwe3GKlHLbboJF53cnbe9lPCsUgWUk1RZAIjO1ZBfJ9RBXNaQZAtEdZBiKEcwVOSvuAZDZD";
	static String appSecret = "07d65aee3d249601ab6be461c5bc1219";
	static String proxyHost = "127.0.0.1";
	static Integer proxyPort = 2125;
	static String pageId = "377653405970342";

	public static void main(String[] args) throws HttpException, IOException {
		facebookClient = new DefaultFacebookClient(accessToken, appSecret, new ProxyWebRequestor(proxyHost, proxyPort),
				new DefaultJsonMapper(), Version.VERSION_2_12);
		System.out.println(facebookClient);
		// 发送facebook返回的结果集

		// 发送facebook成功后返回的帖子ID
		String message = "hello this is a test message！2222";

		// System.out.println("Published message ID: " +
		// publishMessageResponse.getId());

		// 发布图片图片
		String fileName = "demo";
		// InputStream fileStream = new FileInputStream(new
		// File("C:\\Users\\Mr.Lee\\Pictures\\Saved
		// Pictures\\152356mgfk3ev317p12119.jpg"));
		// FacebookType sendPhotos = sendPhotos(facebookClient, pageId, message,
		// fileName, fileStream);
		// System.out.println(sendPhotos);

		// 发布多图
		// String title = "标题";
		// List<String> imagePath = new ArrayList<>();
		// imagePath.add("C:\\Users\\Mr.Lee\\Pictures\\Saved
		// Pictures\\152356mgfk3ev317p12119.jpg");
		// imagePath.add("C:\\Users\\Mr.Lee\\Pictures\\Saved
		// Pictures\\174911drrgrgsoq3anral0.jpg");
		// imagePath.add("C:\\Users\\Mr.Lee\\Pictures\\Saved
		// Pictures\\7730-150331161413-51.jpg");
		// FacebookType sendAlbum = sendAlbum(facebookClient, pageId, title,
		// message, imagePath);
		// System.out.println("发布成功！id为：" + sendAlbum.getId());

		// 发布视频
		// InputStream inputStream = new FileInputStream(new
		// File("D:\\28.mp4"));
		// String description = "这是描述";
		// String fileName = "su";
		// FacebookType sendVideo = sendVideo(facebookClient, pageId, title,
		// fileName, description, inputStream);
		// System.out.println("OK" + sendVideo.getId());

		// 删除帖子
		// boolean delete = delete(facebookClient, "470565566679125", message);

		List<String> deletePhotos = deletePhotos("470574590011556");
		System.out.println(deletePhotos);
	}

	/**
	 * 向主页发送文本消息
	 */
	public static FacebookType sendText(FacebookClient facebookClient, String pageId, String message) {
		return facebookClient.publish(pageId + "/feed", FacebookType.class, Parameter.with("message", message));
	}

	/**
	 * 向主页发布照片
	 */
	@SuppressWarnings("deprecation")
	public static FacebookType sendPhotos(FacebookClient facebookClient, String pageId, String message, String fileName,
			InputStream fileStream) {
		return facebookClient.publish(pageId + "/photos", FacebookType.class,
				BinaryAttachment.with(fileName, fileStream), Parameter.with("message", message));
	}

	/**
	 * 
	 * @param facebookClient
	 * @param pageId
	 * @param title
	 * @param message
	 * @param imagePath
	 * @return
	 * @throws FileNotFoundException
	 */
	@SuppressWarnings("deprecation")
	public static FacebookType sendAlbum(FacebookClient facebookClient, String pageId, String title, String message,
			List<String> imagePath) throws FileNotFoundException {
		FacebookType facebookType = null;
		Album album = facebookClient.publish(pageId + "/albums", Album.class, Parameter.with("name", title),
				Parameter.with("message", message));
		String edge = album.getId() + "/photos";
		for (String fileName : imagePath) {
			FileInputStream fileStream = new FileInputStream(fileName);
			facebookType = facebookClient.publish(edge, FacebookType.class, BinaryAttachment.with(fileName, fileStream),
					Parameter.with("message", message));
		}
		return facebookType;
	}

	/**
	 * 向主页发布视频
	 */
	@SuppressWarnings("deprecation")
	public static FacebookType sendVideo(FacebookClient facebookClient, String pageId, String title, String fileName,
			String description, InputStream fileStream) {
		return facebookClient.publish(pageId + "/videos", FacebookType.class,
				BinaryAttachment.with(fileName, fileStream), Parameter.with("title", title),
				Parameter.with("description", description));
	}

	// 删除发送过的帖子
	public static boolean delete(FacebookClient facebookClient, String publishId, String content) {
		boolean flag = false;
		if (publishId != null && content != null) {
			flag = facebookClient.deleteObject(publishId, Parameter.with("message", content));
		}
		return flag;
	}

	/**
	 * 删除相册中图片，根据文档，相册中图片不能使用GraphAPI删除
	 * 
	 * @param msgId
	 * @return
	 * @throws HttpException
	 * @throws IOException
	 */
	public static List<String> deletePhotos(String msgId) throws HttpException, IOException {
		GetMethod getMethod = null;
		HttpClient httpClient = null;
		String url = MessageFormat.format(albumUrl, "v2.12", msgId, URLEncoder.encode("{id}", "UTF-8"), accessToken);
		System.out.println("url为：" + url);
		httpClient = new HttpClient();
		httpClient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
		if (StringUtil.isNotEmpty(proxyHost) && proxyPort != null && proxyPort.intValue() > 0) {
			// 设置代理服务器地址和端口
			httpClient.getHostConfiguration().setProxy(proxyHost, proxyPort);
		}
		getMethod = new GetMethod(url);
		httpClient.executeMethod(getMethod);
		InputStream result = getMethod.getResponseBodyAsStream();
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(result));
		StringBuffer buffer = new StringBuffer();
		String rs = "";
		while ((rs = bufferedReader.readLine()) != null) {
			buffer.append(rs);
		}
		return parseIdsList(buffer.toString());
	}

	/**
	 * add by lipeng at 2nd Aug,2017 获取相册里面的相片id，放入集合中
	 * 
	 * @param result
	 * @return 相片的id集合
	 */
	private static List<String> parseIdsList(String result) {
		List<String> list = new LinkedList<String>();
		com.alibaba.fastjson.JSONObject data = com.alibaba.fastjson.JSONObject.parseObject(result);
		com.alibaba.fastjson.JSONObject photosNode = data.getJSONObject("photos");
		JSONArray dataNode = photosNode.getJSONArray("data");
		if (photosNode != null && dataNode.size() > 0) {
			for (Object object : dataNode) {
				com.alibaba.fastjson.JSONObject idNode = (com.alibaba.fastjson.JSONObject) object;
				String id = idNode.getString("id");
				if (StringUtil.isNotEmpty(id)) {
					list.add(id);
				}
			}
		}
		return list;
	}

	// 删除发送过的帖子
	public boolean delete(String accessToken, String appSecret, String client_id, String client_secret,
			String proxyHost, Integer proxyPort, String publishID, String content) {
		if (StringUtil.isNotEmpty(proxyHost) && proxyPort != null && proxyPort > 0) {
			facebookClient = new DefaultFacebookClient(accessToken, appSecret,
					new ProxyWebRequestor(proxyHost, proxyPort), new DefaultJsonMapper(), Version.VERSION_2_8);
		} else {
			facebookClient = new DefaultFacebookClient(accessToken, appSecret, Version.VERSION_2_8);
		}
		boolean flag = false;
		if (publishID != null && content != null) {
			flag = facebookClient.deleteObject(publishID, Parameter.with("message", content));
		}

		return flag;
	}
}
