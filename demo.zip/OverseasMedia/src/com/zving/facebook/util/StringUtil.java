package com.zving.facebook.util;

public class StringUtil {
	public static boolean isEmpty(String str){
		return str ==null || "".equals(str);
	}
	public static boolean isNotEmpty(String str){
		return str !=null && !"".equals(str);
	}
	
	public static void main(String[] args) {
		System.out.println(isNotEmpty("cc"));
	}
}
